console.log("hello world")

const navbar = document.getElementById("navbar");

window.addEventListener("scroll", () => {

    console.log("My position Y is ", window.scrollY);

    if( window.scrollY > 50 ) {
        navbar.classList.add("active");

    } else {
   
        navbar.classList.remove("active");

    }




})

var cnt = 0,
  texts = [];

// save the texts in an array for re-use
$(".textContent").each(function() {
  texts[cnt++] = $(this).html();
});

function slide() {
  if (cnt >= texts.length) cnt = 0;
  $('#textMessage').html(texts[cnt++]);
  $('#textMessage')
    .fadeIn(3000)
    .fadeOut('slow', slide);
}
slide();

